package com.example.iptv

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var w: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        w = WebView(this)
        setContentView(w)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.settings.allowFileAccess = true
        w.settings.allowUniversalAccessFromFileURLs = true
        w.webViewClient = WebViewClient()
        w.webChromeClient = WebChromeClient()
        w.loadUrl("file:///android_asset/index.html")
        w.requestFocus()
    }

    override fun onBackPressed() {
        w.evaluateJavascript("window.goBack?goBack():false") { if (it != "true") finish() }
    }
}
